using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.SIP.Proxy
{
    /// <summary>
    /// This class implements SIP presence server.
    /// </summary>
    public class SIP_Presence
    {
        /// <summary>
        /// Default constructor.
        /// </summary>
        public SIP_Presence()
        {
        }

        // TODO:

    }
}
