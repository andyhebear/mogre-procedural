#include <iostream>
#include <string>

using namespace std;

FILE* output;

void sort(int a[], int N);
