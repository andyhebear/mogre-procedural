package Transformer.ASTs;

public abstract class LvalueAST extends ExprAST {
}