package Transformer.ASTs;

public abstract class DirectiveAST extends VarDeclAST{
	public DirectiveAST() {
	}	
}