package Transformer.ASTs;

import org.antlr.runtime.*;

public abstract class OneProcDeclAST extends AST{
	
}