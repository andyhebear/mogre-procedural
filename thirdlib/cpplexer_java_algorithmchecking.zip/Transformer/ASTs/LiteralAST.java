package Transformer.ASTs;

import org.antlr.runtime.*;

public abstract class LiteralAST extends ExprAST {
	public Token literal;

}