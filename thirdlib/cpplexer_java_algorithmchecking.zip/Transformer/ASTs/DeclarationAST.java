//
package Transformer.ASTs;

public abstract class DeclarationAST extends AST {

}
