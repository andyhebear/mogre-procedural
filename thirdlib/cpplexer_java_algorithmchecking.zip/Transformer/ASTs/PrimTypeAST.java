package Transformer.ASTs;

public abstract class PrimTypeAST extends TypeAST {
}