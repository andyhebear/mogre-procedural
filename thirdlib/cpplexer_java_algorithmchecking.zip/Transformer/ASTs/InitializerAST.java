package Transformer.ASTs;

public abstract class InitializerAST extends AST{

}
