package Transformer.ASTs;

public abstract class TypeAST extends AST {	
}