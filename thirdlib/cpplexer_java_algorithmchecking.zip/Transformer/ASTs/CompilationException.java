package Transformer.ASTs;

public class CompilationException extends Exception {

}
