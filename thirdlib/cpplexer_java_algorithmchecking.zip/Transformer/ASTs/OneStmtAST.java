package Transformer.ASTs;

import org.antlr.runtime.*;

public abstract class OneStmtAST extends AST{	
	public Token FirstToken;
}